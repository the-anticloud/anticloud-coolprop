# 25 Millennium Problem Proposals

**Project:** COOLPROP
**Upstream:** https://github.com/CoolProp/CoolProp

Content specific to COOLPROP in category CHEMICAL_PRODUCTION.
