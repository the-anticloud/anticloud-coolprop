# 18 Command Line Interface

**Project:** COOLPROP
**Upstream:** https://github.com/CoolProp/CoolProp

Content specific to COOLPROP in category CHEMICAL_PRODUCTION.
