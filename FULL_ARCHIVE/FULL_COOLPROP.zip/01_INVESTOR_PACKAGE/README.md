# 01 Investor Package

**Project:** COOLPROP
**Upstream:** https://github.com/CoolProp/CoolProp

Content specific to COOLPROP in category CHEMICAL_PRODUCTION.
